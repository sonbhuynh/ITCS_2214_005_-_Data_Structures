import java.util.*;

/**
 * Son Huynh
 * 10/24/2014
 */
public  class TraversalOperations
{
    static Map<String, Integer> nodesThatBeenVisited = new Hashtable<String, Integer>();
    

    static Stack<String> myStack = new Stack<String>();
    static Queue<String> myQueue = new LinkedList<String>();

    public static void depthFirstSearch(String startingNode, Map<String, LinkedList<String>> myDictionary)
    {
    	if ((nodesThatBeenVisited.get(startingNode) == null) || (nodesThatBeenVisited.get(startingNode) != 1))		//Checking if the startingNode has NOT been visited
    	{
    		System.out.println("Starting Node: " + startingNode);		//Print out the starting node
    		nodesThatBeenVisited.put(startingNode, 1);					//Mark the starting node as visited(1)

	        for (String element : myDictionary.get(startingNode))
	        {
	        	if ((nodesThatBeenVisited.get(element) == null) || (nodesThatBeenVisited.get(element) != 1))		//Checking if the element has NOT been visited
	        		myStack.push(element);								//Push the element on top of the stack
	        }	        
    	}
    	
    	if (!myStack.isEmpty())											//Checking if the stack is NOT empty
    		depthFirstSearch(myStack.pop(), myDictionary);				//If not, then pop the top element off of the stack     
    	else
    	{
    		nodesThatBeenVisited.clear();								//If the stack is empty, clear the hashtable
    		System.out.println();										//	so the nodesThatBeenVisited object can be reused
    	}
    }
    
    
    
    public static void breadthFirstSearch(String startingNode, Map<String, LinkedList<String>> myDictionary)
    {
    	if ((nodesThatBeenVisited.get(startingNode) == null) || (nodesThatBeenVisited.get(startingNode) != 1))		//Checking if the startingNode has NOT been visited
    	{    	
	    	System.out.println("Starting Node: " + startingNode);		//Print out the starting node
	    	nodesThatBeenVisited.put(startingNode, 1);					//Mark the starting node as visited(1)
	    	
	    	for (String element : myDictionary.get(startingNode))
	    	{
	    		if ((nodesThatBeenVisited.get(element) == null) || (nodesThatBeenVisited.get(element) != 1))		//Checking if the element has NOT been visited
	        		myQueue.add(element);								//Add the element to the queue
	    	}
    	}
    	
    	if(!myQueue.isEmpty())											//Checking if the queue is NOT empty
    		breadthFirstSearch(myQueue.remove(), myDictionary);			//If not, then remove the first element off of the queue
    	else
    	{
    		nodesThatBeenVisited.clear();								//If the queue is empty, clear the hashtable
    		System.out.println();										//	so the nodesThatBeenVisited object can be reused
    	}
    }
}