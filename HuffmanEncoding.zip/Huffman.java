import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

/**
 * Son Huynh
 * 11/11/2014
 */
public class Huffman
{
	Map<String, Integer> myDictionary;
	
    static Node createTree(Map<String, Integer> myFrequency)
    {
        // What you'd want to do is to create a LinkedList<Node> of nodes
        // Each node is a letter
        // Loop through myDictionary
        // inside the loop, create a node
        // give it the letter
        // give it the value
        // and it should have null left and null right
        //
        // Loop through the nodes, find the two minimum nodes
        // create a new node, assign the left child of it to one of mins
        // assign the right child of it to the other min; value of new
        // node is the sum of the two
        //
        // remove the two nodes from the linkedlist; and add the new one
        // 

    	LinkedList<Node> list = new LinkedList<Node>();		//Declaring variables
    	int min1 = 100;
    	int min2 = 200;
    	String letter1;
    	String letter2;
    	Node n1 = null;
		
    	for (String key: myFrequency.keySet())				//Looping through myDictionary
    	{
    		Node n = new Node();							//Creating a new node
    		n.letter = key;									//Assigning the key to the node's letter
    		n.value = myFrequency.get(key);					//Assigning the key's value to the node's value
    		n.left = null;									//Assigning the node's left to null
    		n.right = null;									//Assigning the node's right to null
    		
    		list.add(n);									//Adding node to the linkedlist
    	}
    	
		int i=0,min1_index=0,min2_index=0;									//Declaring variables
		
    	while(list.size()>1)								//While the list isn't empty
		{
			i=0;											//Declaring variables
			min1_index =-1;
			min2_index =-1;
			
			Node temp1 = null;
			Node temp2 = null;
			
			for (Node node : list)
			{
				if (node.value < min1)							//Finding both minimums in the list
				{
					min2 = min1;								//Assigning min1 to min2
					temp2 = temp1;								//Assigning temp1 to temp2
					min2_index = min1_index;					//Assigning min1_index to min2_index						
					min1 = node.value;							//Assigning node.value to min1
					temp1 = node;								//Assigning node to temp1
					min1_index = i;								//Assigning i to index
				}
        	
				else if ((node.value >= min1) && (node.value < min2))	//If a number is greater than min1, but less than min2
				{
					min2 = node.value;							//Assigning that node.value to min2
					temp2 = node;								//Assigning node to temp2
					min2_index = i;								//Assigning i to min2_index
				}
				
				i++;
			}
			
			n1 = new Node();									//Creating a new node
			n1.value = min1 + min2;								//This new node's value is equal to the 2 minimums
			n1.left = temp1;									//Assigning temp1 to this node's left
			n1.right = temp2;									//Assigning temp2 to this node's right
			
			if(min1_index < min2_index)							//If min1_index is less than min2_index
			{
				list.remove(min1_index);						//Remove the min1_index
				
				if(min2_index > 0)								//If min2_index is greater than 0
					list.remove(min2_index-1);					//Remove min2_index
			}
			else
			{
				list.remove(min2_index);						//Remove the min2_index
				
				if(min1_index > 0)								//If min1_index is greater than 0
					list.remove(min1_index-1);					//Remove min1_index
			}
			
			list.add(n1);										//Add the new node to the list
			min1 = 100;											//Reset both min1 and min2 variables
			min2 = 200;
		}
    	
    	System.out.println();
        return n1;
    }
}