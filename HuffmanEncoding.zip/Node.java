/**
 * Son Huynh
 * 11/11/2014
 */
public class Node
{
    int value;
    String letter;
    Node left;
    Node right;    
}
