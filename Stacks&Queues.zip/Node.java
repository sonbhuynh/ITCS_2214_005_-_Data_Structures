/*	
	Son Huynh
	9/26/2014
	ITCS 2214-005
*/


public class Node
{
	int value;
	Node next;
	
	public Node(int value)
	{
		this.value = value;
		this.next = null;
	}
}
