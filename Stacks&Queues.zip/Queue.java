/*	
	Son Huynh
	9/26/2014
	ITCS 2214-005
*/


public class Queue
{
	Node first;													//Initializing variables
	Node last;
	
	public void enqueue(int x)
	{
		Node node = new Node(x);								//Creating a new node
		
		if (first == null)										//Checking if there is no a queue yet
		{
			first = node;										//If not, the new node created is the first in the queue
			node.next = null;									//The new node's pointer will point to null
		}
		else													//If there is a queue
		{
			Node tempfirst = first;								//Assigning first to tempfirst
			while (tempfirst.next != null)						//Traversing through the queue until a node's pointer hits null,
			{													//		which would indicate the last node.
				tempfirst = tempfirst.next;
			}
			Node templast = last;								//Once we reach the last node, assign last to templast
			tempfirst.next = node;								//The node that was previously last will now point to the new node
			last = node;										//The new node is now assigned as the last node in the queue
			node.next = null;									//The last node's pointer will point to null
		}
	}
	
	public int dequeue()
	{
		if (first == null)										//Checking if there is no queue yet
		{
			System.out.println("There is no queue");
			return -1;
		}
		else													//If there is a queue
		{
			Node tempfirst = first;								//Assigning first to tempfirst
			first = tempfirst.next;								//The second element in the queue is now first
			return tempfirst.value;
		}
	}
	
	public static void main(String[] args)
	{
		Queue queue = new Queue();		
		queue.dequeue();
		queue.enqueue(5);;
		System.out.println(queue.dequeue());
		
	}
}
