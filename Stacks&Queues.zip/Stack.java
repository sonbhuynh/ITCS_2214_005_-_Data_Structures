/*	
	Son Huynh
	9/26/2014
	ITCS 2214-005
*/


public class Stack
{
	Node top;												//Initializing variable
	
	public int pop()
	{
		if (top == null)									//Checking if there is no stack yet
		{
			System.out.println("There is no stack yet");
			return 0;
		}
		else												//If there is a stack
		{
			Node temp = top;								//Assigning top to temp
			top = temp.next;								//Making the next element on the stack as the top, after popping the top element
			return temp.value;								//Returns the element that was popped.
		}
	}
	
	public void push(int x)
	{
		Node node = new Node(x);							//Creating a new node
		
		if (top == null)									//Checking if there is no stack yet
		{
			top = node;										//If not, the new node created is the top of the stack
			node.next = null;								//The new node's pointer will point to null
		}
		else												//If there is a stack 
		{
			Node temp = top;								//Assigning top to temp
			top = node;										//The new node is now the top node of the stack
			node.next = temp;								//The new node's pointer will point to the next node that was previously the top one
		}
	}
	
	public static void main(String[] args)
	{
		Stack stack = new Stack();
		stack.pop();
		stack.push(5);
		
		System.out.println(stack.pop());

		
	}
}
